<?php
defined('MOODLE_INTERNAL') || die();

$functions = [
    'local_sernobre_mcp_upsert_forum' => [
        'classname'    => 'local_sernobre_mcp\\external\\upsert_forum',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_forum in a course section, keyed by a stable idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_upsert_page' => [
        'classname'    => 'local_sernobre_mcp\\external\\upsert_page',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_page in a course section, keyed by a stable idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_delete_module_by_idnumber' => [
        'classname'    => 'local_sernobre_mcp\\external\\delete_module_by_idnumber',
        'methodname'   => 'execute',
        'description'  => 'Delete a course module identified by its idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_update_course_summary' => [
        'classname'    => 'local_sernobre_mcp\\external\\update_course_summary',
        'methodname'   => 'execute',
        'description'  => 'Update the summary (description) of a course',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_upsert_quiz' => [
        'classname'    => 'local_sernobre_mcp\\external\\upsert_quiz',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_quiz shell (no questions), keyed by idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_upload_file' => [
        'classname'    => 'local_sernobre_mcp\\external\\upload_file',
        'methodname'   => 'execute',
        'description'  => 'Upload a base64-encoded file into the course media filearea. Returns pluginfile URL.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_add_questions_gift' => [
        'classname'    => 'local_sernobre_mcp\\external\\add_questions_gift',
        'methodname'   => 'execute',
        'description'  => 'Parse GIFT text, create questions in a course bank category, append them to an existing quiz by idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities,moodle/question:add',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_delete_module_by_cmid' => [
        'classname'    => 'local_sernobre_mcp\\external\\delete_module_by_cmid',
        'methodname'   => 'execute',
        'description'  => 'Delete a course_module by its cmid (use for modules without idnumber)',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_promote_quiz_questions' => [
        'classname'    => 'local_sernobre_mcp\\external\\promote_quiz_questions',
        'methodname'   => 'execute',
        'description'  => 'Promote all question_versions linked to a quiz from status=draft to status=ready',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_repair_quiz_sections' => [
        'classname'    => 'local_sernobre_mcp\\external\\repair_quiz_sections',
        'methodname'   => 'execute',
        'description'  => 'Ensure a quiz has a default quiz_sections row (firstslot=1)',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_upsert_url' => [
        'classname'    => 'local_sernobre_mcp\\external\\upsert_url',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_url in a course section, keyed by a stable idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_upsert_assignment' => [
        'classname'    => 'local_sernobre_mcp\\external\\upsert_assignment',
        'methodname'   => 'execute',
        'description'  => 'Create or update a mod_assign in a course section, keyed by a stable idnumber',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_promote_all_drafts_in_course' => [
        'classname'    => 'local_sernobre_mcp\\external\\promote_all_drafts_in_course',
        'methodname'   => 'execute',
        'description'  => 'Promote every question_versions.status=draft to ready across all quizzes in a course (fixes the silent-edit bug in Moodle 4.5+/5.x)',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_update_question_simple' => [
        'classname'    => 'local_sernobre_mcp\\external\\update_question_simple',
        'methodname'   => 'execute',
        'description'  => 'Direct DB update of question name / questiontext / answers, bypassing the Moodle edit form that fails silently in Moodle 5.0.2 qbank',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_duplicate_section' => [
        'classname'    => 'local_sernobre_mcp\\external\\duplicate_section',
        'methodname'   => 'execute',
        'description'  => 'Duplicate all modules from a source section into a new section in the same course',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_get_quiz_questions' => [
        'classname'    => 'local_sernobre_mcp\\external\\get_quiz_questions',
        'methodname'   => 'execute',
        'description'  => 'List all questions attached to a quiz (read-only)',
        'type'         => 'read',
        'capabilities' => 'moodle/course:view',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_get_assignment_config' => [
        'classname'    => 'local_sernobre_mcp\\external\\get_assignment_config',
        'methodname'   => 'execute',
        'description'  => 'List submission configuration of mod_assign instances in a course (read-only): enabled submission plugins, max files, word limit, due dates',
        'type'         => 'read',
        'capabilities' => 'moodle/course:view',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_ensure_manual_enrolment' => [
        'classname'    => 'local_sernobre_mcp\\external\\ensure_manual_enrolment',
        'methodname'   => 'execute',
        'description'  => 'Create a manual enrolment instance in a course if it is missing (idempotent)',
        'type'         => 'write',
        'capabilities' => 'enrol/manual:config',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_create_section' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'methodname'   => 'create_section',
        'description'  => 'Create a course section with name/summary/visibility (idempotent by name)',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_update_section' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'methodname'   => 'update_section',
        'description'  => 'Update a course section name/summary/visible/position; visibility propagates to its modules',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_reorder_sections' => [
        'classname'    => 'local_sernobre_mcp\\external\\reorder_sections',
        'methodname'   => 'execute',
        'description'  => 'Reorder course sections in one deterministic batched call',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    // Compatibility API embedded from local_wsmanagesections.
    'local_sernobre_mcp_create_sections' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'methodname'   => 'create_sections',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'description'  => 'Create one or more course sections at a position',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update,moodle/course:movesections',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_delete_sections' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'methodname'   => 'delete_sections',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'description'  => 'Delete course sections by number or id',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_move_section' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'methodname'   => 'move_section',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'description'  => 'Move a course section to a position',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update,moodle/course:movesections',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_get_sections' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'methodname'   => 'get_sections',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'description'  => 'Get detailed course section settings',
        'type'         => 'read',
        'capabilities' => 'moodle/course:view',
        'ajax'         => true,
    ],
    'local_sernobre_mcp_update_sections' => [
        'classname'    => 'local_sernobre_mcp_legacy_sections_external',
        'methodname'   => 'update_sections',
        'classpath'    => 'local/sernobre_mcp/legacy_sections.php',
        'description'  => 'Update multiple course sections',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'ajax'         => true,
    ],

    // Names used by the removed plugin, kept as aliases during migration.
    'local_wsmanagesections_create_sections' => [
        'classname' => 'local_sernobre_mcp_legacy_sections_external', 'methodname' => 'create_sections',
        'classpath' => 'local/sernobre_mcp/legacy_sections.php', 'description' => 'Legacy alias: create sections',
        'type' => 'write', 'capabilities' => 'moodle/course:update,moodle/course:movesections', 'ajax' => true,
    ],
    'local_wsmanagesections_delete_sections' => [
        'classname' => 'local_sernobre_mcp_legacy_sections_external', 'methodname' => 'delete_sections',
        'classpath' => 'local/sernobre_mcp/legacy_sections.php', 'description' => 'Legacy alias: delete sections',
        'type' => 'write', 'capabilities' => 'moodle/course:update', 'ajax' => true,
    ],
    'local_wsmanagesections_move_section' => [
        'classname' => 'local_sernobre_mcp_legacy_sections_external', 'methodname' => 'move_section',
        'classpath' => 'local/sernobre_mcp/legacy_sections.php', 'description' => 'Legacy alias: move section',
        'type' => 'write', 'capabilities' => 'moodle/course:update,moodle/course:movesections', 'ajax' => true,
    ],
    'local_wsmanagesections_get_sections' => [
        'classname' => 'local_sernobre_mcp_legacy_sections_external', 'methodname' => 'get_sections',
        'classpath' => 'local/sernobre_mcp/legacy_sections.php', 'description' => 'Legacy alias: get sections',
        'type' => 'read', 'capabilities' => 'moodle/course:view', 'ajax' => true,
    ],
    'local_wsmanagesections_update_sections' => [
        'classname' => 'local_sernobre_mcp_legacy_sections_external', 'methodname' => 'update_sections',
        'classpath' => 'local/sernobre_mcp/legacy_sections.php', 'description' => 'Legacy alias: update sections',
        'type' => 'write', 'capabilities' => 'moodle/course:update', 'ajax' => true,
    ],
];

// Dedicated service for the Sernobre MCP integration.
// Course deletion is intentionally not included by default.
$services = [
    'sernobre_mcp' => [
        'functions' => [
            // Core functions used for site discovery and course management.
            'core_webservice_get_site_info',

            // Course operations.
            'core_course_get_courses_by_field',
            'core_course_create_courses',
            'core_course_update_courses',
            'core_course_duplicate_course',
            'core_course_get_contents',
            'core_course_edit_section',
            'core_course_edit_module',
            'core_completion_get_activities_completion_status',

            // Enrolment & users.
            'core_enrol_get_enrolled_users',
            'core_enrol_get_users_courses',
            'core_user_get_users_by_field',
            'core_user_create_users',
            'core_user_update_users',
            'core_role_assign_roles',
            'enrol_manual_enrol_users',
            'enrol_manual_unenrol_users',

            // Groups.
            'core_group_create_groups',
            'core_group_add_group_members',

            // Calendar operations.
            'core_calendar_create_calendar_events',
            'core_calendar_get_calendar_events',
            'core_calendar_update_event_start_day',
            'core_calendar_delete_calendar_events',
            'core_calendar_get_allowed_event_types',

            // Forum operations.
            'mod_forum_get_forums_by_courses',
            'mod_forum_add_discussion',

            // Assignment operations.
            'mod_assign_get_submissions',
            'mod_assign_get_submission_status',
            'mod_assign_save_submission',
            'mod_assign_submit_for_grading',
            'mod_assign_save_grade',

            // Quiz operations.
            'mod_quiz_get_user_quiz_attempts',
            'mod_quiz_get_attempt_review',

            // Gradebook operations.
            'gradereport_user_get_grade_items',

            // Messaging.
            'core_message_send_instant_messages',

            // Badges.
            'core_badges_get_user_badges',

            // Files (submission workflow).
            'core_files_upload',

            // Companion-plugin functions.
            'local_sernobre_mcp_upsert_forum',
            'local_sernobre_mcp_upsert_page',
            'local_sernobre_mcp_delete_module_by_idnumber',
            'local_sernobre_mcp_update_course_summary',
            'local_sernobre_mcp_upsert_quiz',
            'local_sernobre_mcp_upload_file',
            'local_sernobre_mcp_add_questions_gift',
            'local_sernobre_mcp_delete_module_by_cmid',
            'local_sernobre_mcp_promote_quiz_questions',
            'local_sernobre_mcp_repair_quiz_sections',
            'local_sernobre_mcp_upsert_url',
            'local_sernobre_mcp_upsert_assignment',
            'local_sernobre_mcp_promote_all_drafts_in_course',
            'local_sernobre_mcp_update_question_simple',
            'local_sernobre_mcp_duplicate_section',
            'local_sernobre_mcp_get_quiz_questions',
            'local_sernobre_mcp_get_assignment_config',
            'local_sernobre_mcp_ensure_manual_enrolment',
            'local_sernobre_mcp_create_section',
            'local_sernobre_mcp_update_section',
            'local_sernobre_mcp_reorder_sections',
            'local_sernobre_mcp_create_sections',
            'local_sernobre_mcp_delete_sections',
            'local_sernobre_mcp_move_section',
            'local_sernobre_mcp_get_sections',
            'local_sernobre_mcp_update_sections',
        ],
        'restrictedusers' => 1,
        'enabled' => 1,
        'shortname' => 'sernobre_mcp',
        'downloadfiles' => 0,
        'uploadfiles' => 0,
    ],
];
